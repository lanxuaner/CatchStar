"use strict";
cc._RF.push(module, '12d2asL0VRFOpLxEFTd3Mkd', 'Global');
// startMenu/scripts/Global.ts

window["G"] = {
    startScene: "StartScene",
    appId: "wxc483083706566fb5",
};

cc._RF.pop();